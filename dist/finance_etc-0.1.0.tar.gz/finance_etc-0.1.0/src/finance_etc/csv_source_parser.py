import pandas as pd
import duckdb as db
