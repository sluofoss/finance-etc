# related project for reference

<https://amortizer.readthedocs.io/en/latest/amortizer.html>

# current workbook for testing refactoring 
`analysis_nb/finance_refactored.ipynb`

#TODO 
- need to decouple bank info from mortgage calc


# trial out using metabase or superset for dashboard creation
https://github.com//AlexR2D2/metabase_duckdb_driver?tab=readme-ov-file
https://github.com/MotherDuck-Open-Source/metabase_duckdb_driver


```

docker run --name metaduck -v ${PWD}:/container/myfiles -d -p 80:3000 -m 2GB -e MB_PLUGINS_DIR=/home/plugins metaduck:50.29

```